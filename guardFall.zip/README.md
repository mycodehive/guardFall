## [🛡️ 배려대상자(노인, 아이 등) 낙상 감지 및 알림 시스템 소개 Wiki로 이동](https://github.com/mycodehive/guardFall/wiki)

### 소개영상 : [https://youtu.be/ecgpAeGIZnI](https://youtu.be/ecgpAeGIZnI)
